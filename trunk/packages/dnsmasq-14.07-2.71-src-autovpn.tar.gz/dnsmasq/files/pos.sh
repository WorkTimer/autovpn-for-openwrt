#!/bin/sh
INCLUDE_ONLY=1

. ../netifd-proto.sh
. ./ppp.sh
init_proto "$@"

proto_pos_init_config() {
	ppp_generic_init_config
	proto_config_add_string sudo
	proto_config_add_string server
	proto_config_add_string sshuser
	proto_config_add_string ipaddr
	proto_config_add_string peeraddr
	proto_config_add_string ssh_options
	proto_config_add_string identity
	proto_config_add_int port
	available=1
	no_device=1
}

proto_pos_setup() {
	local config="$1"
	local iface="$2"
	local ip serv_addr errmsg
	local opts pty

	json_get_vars sudo port sshuser identity ipaddr peeraddr ssh_options
	json_get_var server server && {
		for ip in $(nslookup $server|sed -n '/Name:/,$ p'|cut -d' ' -f3); do
			( proto_add_host_dependency "$config" "$ip" )
			serv_addr=1
		done
	}
	[ -n "$serv_addr" ] || errmsg="${errmsg}Could not resolve $server.\n"
	[ -n "$sshuser" ] || errmsg="${errmsg}Missing sshuser option.\n"
	[ -z "$identity" ] && identity="'/root/.ssh/id_rsa'" 
	[ -f "$identity" ] || errmsg="${errmsg}Cannot find valid identity file.\n"
	[ -n "$errmsg" ] && {
		echo -ne "$errmsg"
		sleep 5
		proto_setup_failed "$config"
		exit 1
	}
	opts="-i $identity"
	opts="$opts ${port:+-p $port}"
	opts="$opts ${ssh_options}"
	opts="$opts $sshuser@$server"
	sudo="${sudo:+sudo}"
	pty="env 'HOME=$home' /usr/bin/ssh $opts $sudo pppd nodetach notty noauth"

	#ppp_generic_setup "$config" \
	#	noauth pty "$pty" "$ipaddr:$peeraddr"

        proto_run_command "$config" /usr/sbin/pppd \
                ifname "pos-$config" \
                nodetach \
		silent \
		noauth \
		nodeflate \
                lcp-echo-interval 3 lcp-echo-failure 5 \
                nodefaultroute \
		ip-up-script /lib/netifd/pos-up \
		ip-down-script /lib/netifd/pos-down \
                pty "$pty" \
		"$ipaddr:$peeraddr"
}

proto_pos_teardown() {
	ppp_generic_teardown "$@"
}

add_protocol pos
