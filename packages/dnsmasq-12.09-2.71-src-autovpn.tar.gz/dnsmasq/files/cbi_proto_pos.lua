local map, section, net = ...

local server, port, username, password, identity, ipaddr, peeraddr, ssh_options


server = section:taboption("general", Value, "server", translate("SSH Server"))
server.datatype = "host"

port = section:taboption("general", Value, "port", translate("Port"))
port.datatype = "port"
port.default = 22

sshuser = section:taboption("general", Value, "sshuser", translate("User"))
sshuser.default = "root"

identity = section:taboption("general", Value, "identity", translate("Identity key file"))
identity.datatype = "file"
identity.default = "/root/.ssh/id_rsa"

math.randomseed(os.time())
a=math.random(256)%256
b=math.random(256)%256

ipaddr = section:taboption("general", Value, "ipaddr", translate("Local IP"))
ipaddr.datatype = "ip4addr"
ipaddr.default = "10." .. a .. "." .. b .. ".1"

peeraddr = section:taboption("general", Value, "peeraddr", translate("Remote IP"))
peeraddr.datatype = "ip4addr"
peeraddr.default = "10." .. a .. "." .. b .. ".2"

ssh_options = section:taboption("general", Value, "ssh_options", translate("SSH Options"))
ssh_options.default = "-y"

if delegate then
        delegate.default = delegate.disabled
end
if fwzone then
        fwzone.default = "wan"
end
